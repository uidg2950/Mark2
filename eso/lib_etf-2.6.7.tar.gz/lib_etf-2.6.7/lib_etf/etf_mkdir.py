#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import lib_etf.other
import os
import time


def mkdir(self, etf_id: int, folder_name, eso_releases=None):
    '''
        **etf_id:** The destination folder (user must have write access in there).

        **folder_name:** Name of the subfolder that will be created.

        **eso_releases:** Eso-Release(s) will be added as a folder metadata.

        **return value:** `etf_id` of the new subfolder.
    '''

    ret = self.session.get(self.api_url + "mkdir.php",
                           params={"etf_id": etf_id, "title": folder_name, "eso_releases": eso_releases},
                           timeout=self.timeout)
    
    if ret.status_code != 200:
        raise LookupError("(FROM SERVER) " + ret.text)
    
    try:
        answer = ret.json()
    except:
        raise IOError("(FROM SERVER) " + ret.text)

    if answer["success"]:
        return answer["new_folder_etf_id"]
    else:
        raise IOError("(FROM SERVER) " + answer["reason"])
