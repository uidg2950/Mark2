#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import lib_etf.progressbar
import time


# small helper functions

def mib(bytes):
    '''
        Helper function, that converts *bytes* to a string like this: `9.23 MiB`.
        If *bytes* is smaller than `1 MiB`, the output is in `KiB`, and for sizes bigger than
        one gigabyte, the output is in `GiB`.
    '''

    # Display KiB instead of MiB for small files
    if int(bytes) < 1024 * 1024:
        return str(round(int(bytes) / 1024, 2)) + " KiB"

    # Display MiB for files smaller than 1 GiB
    if int(bytes) < 1024 * 1024 * 1024:
        return str(round(int(bytes) / 1024 / 1024, 2)) + " MiB"

    # Display GiB for the rest.
    return str(round(int(bytes) / 1024 / 1024 / 1024, 2)) + " GiB"


def sane_name(name):
    '''
        Creates a sane file name from `name` by removing characters that some file-systems
        may not like, for example the forward-slash `/`.
    '''

    # http://stackoverflow.com/a/7406369
    keepcharacters = (' ', '.', '_', '[', ']', '(', ')', '-')
    return "".join(c for c in name if c.isalnum() or c in keepcharacters).rstrip()


def chunk_max(chunk_size, size_final, done):
    '''
        Maximum possible chunk size might be smaller than chunk_size!
    '''
    if done < size_final and (size_final - done < chunk_size):
        return size_final - done
    return chunk_size


# http://stackoverflow.com/a/519653
# did_run: allow uploading empty files
def read_in_chunks(handle, chunk_size, size_final, done):
    did_run = False
    while True:
        data = handle.read(chunk_max(chunk_size, size_final, done))
        if not data and did_run:
            break
        yield data
        did_run = True
        done += len(data)


def hash_beginning_of_file(handle, hash, chunk_size, size_final, skipped, interactive):
    '''
        Helper function used internally in the upload and download methods.

        **handle**: File handle as returned by `open()` to the file, that should get hashed.

        **hash**: Already initialized `hashlib.md5()` object, that will get updated.

        **chunk_size**: Amount of bytes that will be hashed at once.

        **skipped**: How many bytes will get hashed of the beginning of the file.

    '''
    done = 0
    time_start = time.time()
    for chunk in read_in_chunks(handle, chunk_size, skipped, done):
        hash.update(chunk)
        done += len(chunk)
        if interactive:
            lib_etf.progressbar.draw(skipped, size_final, done, time_start)
        if done >= skipped:
            return
