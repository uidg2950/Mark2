#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import lib_etf.other
import os
import time


def mkassoc(self, link_folder_id: int, target_id: int):
    '''
        Create an association *(link)*.

        **link_folder_id:** `etf_id` of the folder, in which the new association will be created
            (user must have write access in there).

        **target_id:** `etf_id` of the file or folder, that the association will point to.

        **return value:** `etf_id` of the new association.
    '''

    ret = self.session.get(self.api_url + "mkassoc.php",
                           params={"target_id": target_id, "link_folder_id": link_folder_id}, timeout=self.timeout)
    
    if ret.status_code != 200:
        raise LookupError("(FROM SERVER) " + ret.text)
    
    try:
        answer = ret.json()
    except:
        raise IOError("(FROM SERVER) " + ret.text)

    if answer["success"]:
        return answer["new_assoc_etf_id"]
    else:
        raise IOError("(FROM SERVER) " + answer["reason"])
