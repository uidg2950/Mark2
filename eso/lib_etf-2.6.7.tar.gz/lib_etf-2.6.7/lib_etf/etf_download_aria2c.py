#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import time
import subprocess
import logging
import os
from . import requests
from pprint import pprint


class ETFParallelDownloadRequirementError(Exception):
    pass


# aria2c is a commandline download tool, that supports downloading with multiple connections in
# parallel: https://aria2.github.io/
# Here are some wrapper functions, that use the commandline client.

def _download_require_aria2c(self):
    if os.name != "posix":
        raise ETFParallelDownloadRequirementError("ERROR: Parallel downloads with aria2 are"
                                                  " only supported on GNU/Linux (posix), not on " + os.name + ".")

    # Run "aria2c -v" and parse the output
    version = None
    features = None
    try:
        ret = subprocess.check_output(["aria2c", "-v"])
    except OSError:
        raise ETFParallelDownloadRequirementError("ERROR: aria2c could not be executed. Did "
                                                  + " you install aria2?\n"
                                                  + "NOTE: aria2c is only required, if you want to download with multiple"
                                                  + " connections at once.")

    for line in ret.split("\n"):
        if "aria2 version" in line:
            version = line.split(" ")[2]
        if "Enabled Features:" in line:
            features = line.split(": ")[1]

    # Check for required strings
    if not features or not version:
        raise ETFParallelDownloadRequirementError("ERROR: aria2c found, but could not detect"
                                                  + " which features are enabled. Please contact the ETF support and attach the"
                                                  + " output of 'aria2c -v'.")

    for feature in ["HTTPS"]:
        if not feature in features:
            raise ETFParallelDownloadRequirementError("ERROR: aria2c found, but a required"
                                                      " feature is not enabled: " + feature)

    self.log.debug("aria2 version: " + version)
    self.log.debug("aria2 features: " + features)
    self.aria2c_version = version


def _download_aria2c(self, etf_id: int, md5sum, output_path):
    cookies = requests.utils.dict_from_cookiejar(self.session.cookies)
    user_agent = "aria2/" + self.aria2c_version + " " + self.session.headers["user-agent"]
    cmd = ["aria2c",
           "--max-connection-per-server=" + str(self.connections),
           "--max-concurrent-downloads=8",
           "--continue",
           "--max-tries=1",  # we already retry in libetf
           "--ca-certificate=" + self.session.verify,
           "--user-agent=" + user_agent,
           "--header=Cookie: PHPSESSID=" + cookies["PHPSESSID"],
           # "out" is always relative to "dir", so we set it to "/"
           "--out=" + output_path[1:],
           "--dir=/"
           ]

    if md5sum:
        cmd += ["--checksum=md5=" + md5sum]

    if os.getenv("ETF_API_HTTP_AUTH_USER"):
        cmd += ["--http-user=" + os.getenv("ETF_API_HTTP_AUTH_USER"),
                "--http-passwd=" + os.getenv("ETF_API_HTTP_AUTH_PASS")]

    # Adjust verbosify
    log_level = self.log.getEffectiveLevel()
    if log_level > logging.INFO:
        cmd += ["--quiet"]
    elif log_level == logging.INFO:
        cmd += ["--console-log-level=warn"]
    elif log_level < logging.INFO:
        cmd += ["--console-log-level=notice"]

    cmd += [self.api_url + "download.php?etf_id=" + etf_id]

    self.log.debug("# " + " ".join(cmd))

    # This raises an exception, when the exit code is not 0
    subprocess.call(cmd)
