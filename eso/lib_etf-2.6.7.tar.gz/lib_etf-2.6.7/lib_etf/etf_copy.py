#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import json


def copy(self, source_ids, etf_id: int):
    '''
        **source_ids:** List of entries, that should be copied. You must have write access for that entry.
        Folders can only be copied, if they do not contain any subfolders.

        **etf_id:** Destination folder id.

        This function returns a dictionary with the copied elements or raises an `IOError`
            exception with an error message.
    '''
    ret = self.session.post(self.api_url
                            + "copy.php", data={'source_ids': ",".join(source_ids), 'etf_id': etf_id},
                            timeout=self.timeout)
    
    if ret.status_code != 200:
        raise LookupError("(FROM SERVER) " + ret.text)
    
    try:
        answer = ret.json()
    except:
        raise IOError("(FROM SERVER) " + ret.text)

    if answer["success"] == True:
        self.log.info("Successfully copied selected entries.")
        return answer["dict"]
    else:
        raise IOError("(FROM SERVER) " + str(answer["reason"]))
