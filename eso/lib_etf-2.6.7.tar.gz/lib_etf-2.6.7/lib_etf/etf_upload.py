#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import lib_etf.progressbar
import lib_etf.other
import os
import hashlib
import time
import urllib
import sys
import traceback
import logging


class ETFUploadFatalError(Exception):
    pass


def upload_list_unfinished(self, force_refresh=False):
    '''
        **force_refresh:** Instead of the cached list (from the last login), get new data.
            Only use this option, if you let much time pass between the login and the call
            of this function, and you really need the new data.

        **return value:** Dictionary of uploads that can be continued from the server.
        Here's how the structure looks like:

            {
                [
                    "id": ..., // upload session id
                    "start_date": ...,
                    "last_update": ...,
                    "file_name": ...,
                    "parent_id": ..., // target folder
                    "size_current": ..., // size in bytes
                    "size_final": ... // size in bytes
                ],
                ... // more entries
            }

    '''
    if force_refresh: self._login()
    return self.unfinished


# Returns: {size_current: ..., id: ...} or None
def _upload_get_resume_data(self, etf_id: int, file_title, size_final):
    try:
        file_title = file_title.decode("utf-8")
    except AttributeError:
        pass

    for entry in self.unfinished:
        # entry["file_name"]: unicode
        # file_title: str
        if (entry["file_name"] != file_title
                or int(entry["parent_id"]) != int(etf_id)
                or int(entry["size_final"]) != size_final):
            continue
        return entry
    return None


def _upload_chunk_url(self, etf_id: int, file_title, size_final, done, chunk_len, session_id,
                      md5sum):
    '''
        Build the upload URL for a single chunk.

        **session_id:** A valid upload session ID or None.

        **md5sum:** Result of `hash.hexdigest()`.
    '''
    try:
        file_title_quoted = urllib.quote(file_title)
    except:
        file_title_quoted = urllib.parse.quote(file_title)  # python3

    ret = self.api_url + "upload.php"
    ret += "?etf_id=" + str(etf_id)
    ret += "&file_title=" + file_title_quoted
    ret += "&size_final=" + str(size_final)
    ret += "&size_chunk_start=" + str(done)
    ret += "&size_chunk_length=" + str(chunk_len)

    if session_id:
        ret += "&session_id=" + str(session_id)

    if md5sum:
        ret += "&md5sum=" + md5sum

    return ret


def _upload_chunk(self, etf_id: int, file_title, time_start, size_final, skipped, done, chunk,
                  chunk_len, session_id, md5sum):
    '''
        **return value:** {"session_id": 591} or {"etf_id": 1234567}
    '''
    url = self._upload_chunk_url(etf_id, file_title, size_final, done, chunk_len, session_id,
                                 md5sum)

    if md5sum:
        if self.interactive:
            print()  # start a new line for log output
        self.log.info("Clientside MD5: " + md5sum)
        if size_final > 500 * 1024 * 1024:  # 500 MB
            self.log.info("Verification on the serverside might take some time, please be"
                          " patient!")

    # do the upload (prints url in verbose mode)
    if logging.getLogger("lib_etf").getEffectiveLevel() <= logging.DEBUG:
        print()  # start a new line for log output
    self.session.close()
    response = self.session.put(url, data=chunk, timeout=self.timeout, verify = False)

    if response.status_code != 200:
        raise LookupError("(FROM SERVER) " + ret.text)

    try:
        ret = response.json()
    except:
        raise IOError("(FROM SERVER) " + response.text)

    if ret["success"] != True:
        if "is_fatal" in ret and ret["is_fatal"]:
            raise ETFUploadFatalError("(FATAL ERROR FROM SERVER) " + ret["reason"])
        raise IOError("(FROM SERVER) " + ret["reason"])

    if "upload_etf_id" in ret:
        self.log.info("MD5 verified on server, upload successful!")
        return {"etf_id": ret["upload_etf_id"]}

    if "existing_id" in ret:
        self.log.info("File has already been uploaded as ETF-ID: " + str(ret["existing_id"]) +
                      " (same size and file name). Skipping...")
        return {"etf_id": ret["existing_id"]}

    if self.interactive:
        lib_etf.progressbar.draw(skipped, size_final, done, time_start)

    if "session_id" in ret:
        return {"session_id": ret["session_id"]}


def _upload_entry_file(self, etf_id: int, path, file_title, chunk_size):
    # file infos
    if not os.path.isfile(path):
        raise ETFUploadFatalError("File not found on disk: " + path)
    if not file_title:
        file_title = os.path.basename(path)
    size_final = os.path.getsize(path)

    # progress infos
    resume_data = self._upload_get_resume_data(etf_id, file_title, size_final)
    session_id = int(resume_data["id"]) if resume_data else None
    skipped = int(resume_data["size_current"]) if resume_data else 0
    hash = hashlib.md5()
    md5sum = None

    with open(path, "rb") as handle:

        # resume upload if possible
        if skipped > 0:
            self.log.info("Resuming " + file_title + " at " + lib_etf.other.mib(skipped) + " / "
                          + lib_etf.other.mib(size_final) + "...")
            lib_etf.other.hash_beginning_of_file(handle, hash, chunk_size, size_final, skipped,
                                                 self.interactive)
        else:
            self.log.info("Uploading " + file_title + "... (size: " + lib_etf.other.mib(size_final)
                          + ")")

        # upload the rest in chunks
        done = skipped
        time_start = time.time()
        for chunk in lib_etf.other.read_in_chunks(handle, chunk_size, size_final, done):
            chunk_len = len(chunk)
            hash.update(chunk)
            if chunk_len + done >= size_final:  # last chunk, send MD5
                md5sum = hash.hexdigest()

            ret = self._upload_chunk(etf_id, file_title, time_start, size_final, skipped, done,
                                     chunk, chunk_len, session_id, md5sum)

            done += chunk_len
            if "session_id" in ret:
                session_id = ret["session_id"]
            if "etf_id" in ret:
                return ret["etf_id"]


def upload(self, etf_id: int, input_file, chunk_size=1024 * 1024 * 5, auto_resume=True,
           file_title=None, retry_attempts=10, retry_sleep=5):
    '''
        **etf_id:** The destination folder (user must have write access in there).

        **input_file:** File, that will get uploaded.

        **chunk_size:** How much data will be uploaded at once (Default: `5 MiB`). When you
            lose your connection, this is the maximum size that will get lost when you resume.
            If you have a *fast* connection to the server, set this to a high value
            (eg. `50 MiB`) to reduce overhead. If you have a *slow connection that fails
            often*, you may even set this to a lower value.

        **auto_resume:** Automatically try to resume an upload.

        **file_title:** The title, that the file will have on the server (Default: Name of the
            file).

        **retry_attempts:** Amount of automatic retries, when the connection breaks down.

        **retry_sleep:** Time to wait between retries, in seconds.

        **return value:** `etf_id` of the uploaded file, raises various exceptions on errors.

        If a file already exists in the target folder, and it has the same name and size, this
        function will return the ETF-ID of the existing file *(new in version
        [1204](#Changelog-1204)).*
    '''

    retry_attempts = int(retry_attempts)
    retry_sleep = float(retry_sleep)

    for i in range(retry_attempts + 1):
        try:
            # refresh the unfinished uploads list on every retry
            if i > 0:
                self.upload_list_unfinished(force_refresh=True)

            return self._upload_entry_file(etf_id, input_file, file_title, chunk_size)

        except ETFUploadFatalError:
            raise
        except:
            self.log.debug(traceback.format_exc())
            self.log.error(str(sys.exc_info()[1]))
            if i == retry_attempts:
                self.log.critical("Upload failed, no retries left!")
                raise
            self.log.error(str(retry_attempts - i - 1) + " retry attempts remaining.")
            self.log.error("Sleeping " + str(retry_sleep) + " seconds before retry...")
            time.sleep(retry_sleep)
