from __future__ import print_function, division, absolute_import

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding

class EncryptionError(Exception):
    pass

def encrypt_data(self, data):
    resp = get_public_encryption_key(self.api_url + "get_public_key.php", self.session)

    if not resp["success"]:
        raise EncryptionError("Failed to get encryption key: " + resp["reason"])

    public_key = serialization.load_pem_public_key(bytes(resp["data"], "utf-8"), default_backend())

    cipher = public_key.encrypt(
        bytes(data, "utf-8"),
        padding.OAEP(
            mgf=padding.MGF1(
                algorithm=hashes.SHA1()
            ),
            algorithm=hashes.SHA1(),
            label=None
        )
    )

    return cipher.hex()

def get_public_encryption_key(public_key_cert_url, session_obj):
    session_obj.verify=False
    resp = session_obj.get(public_key_cert_url, verify=False)
    if resp.status_code != 200:
        LookupError("(FROM SERVER) " + resp.text)

    try:
        return resp.json()
    except Exception:
        return {
            "success": False,
            "reason": resp.text
        }
