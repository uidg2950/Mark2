#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import lib_etf.other
import lib_etf.progressbar
import os
import hashlib
import time
import traceback
import sys


class ETFDownloadFatalError(Exception):
    pass


# Code, that gets executed for all types of entries (files, folders, associations)
def _download_entry_prepare(self, entry, queue, done):
    if not entry["path"]:
        entry["path"] = os.getcwd()

    # get and log basic metadata
    self.log.info("Queue item: " + str(done + 1) + " / " + str(len(queue) + done + 1))
    if not entry["meta"]:
        entry["meta"] = self.list(entry["id"])
    if not "entry_type" in entry["meta"]:
        raise IOError("Could not read metadata for ETF-ID " + str(entry["id"]) + "."
                                                                                 " Possibly your connection to the Internet is down.")

    self.log.info("ETF-ID:     " + str(entry["id"]))
    self.log.info("Type:       " + entry["meta"]["entry_type"])
    if entry["meta"]["entry_type"] != "ASSOCIATION":
        self.log.info("Title:      " + entry["meta"]["title"])
    if entry["meta"]["entry_type"] == "FILE":
        self.log.info("Size:       " + lib_etf.other.mib(int(entry["meta"]["file_size"])))


def _download_entry_association(self, entry, queue, follow_associations):
    if not follow_associations:
        self.log.info("Skipping association (follow_associations is set to False)...")
        return

    # associated entry has been deleted
    if entry["meta"].get("associated_entry") is None:
        self.log.info("Skipping association: " + entry["meta"]["_associated_entry_note"])
        return

    # resolve the association
    meta = entry["meta"]["associated_entry"]
    if meta["entry_type"] == "FOLDER":
        self.log.info("Skipping association, because it points to a folder.")
        self.log.debug("Folder associations are bidirectional, so if you intended to download")
        self.log.debug("a folder, please use the resolved ETF-ID. List the association for")
        self.log.debug("more information (for example with: etf.py list " + entry["id"] + ").")
        return

    self.log.info("Appended resolved association to the queue.")

    queue.append({'id': entry["meta"]["associated_entry"]["id"],
                  'meta': meta, 'name': entry["name"], 'path': entry["path"]})


# folders: recurse only once (If your workflow needs recursion in deeper levels of folders, you
# should improve your workflow. Ask the ETF support for more information.)
def _download_entry_folder(self, entry, queue, done, allow_folder_download, create_subfolder):
    if not allow_folder_download:
        raise ETFDownloadFatalError("ETF-ID " + etf_id + " (" + entry["meta"]["title"] + ")"
                                    + " is a folder, but the 'allow_folder_download'-flag is not set to true!")

    if done > 0:
        self.log.info("Skipping subfolder (If your workflow needs recursing in deeper levels")
        self.log.info("of folders, you should improve your workflow. Ask the ETF support for")
        self.log.info("more information.)")
        return

    path = entry["path"]
    if create_subfolder:
        path = os.path.join(path, lib_etf.other.sane_name(entry["meta"]["title"]))

    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception as e:
            raise ETFDownloadFatalError("Could not create directory structure '" + path + "': "
                                        + str(e))

    for i in range(len(entry["meta"]["content"])):
        meta = entry["meta"]["content"][i]
        queue.append({'id': meta["id"], 'meta': meta, 'name': None, 'path': path})


def _download_entry_file(self, entry, auto_resume, chunk_size,
                         existing_file_check_md5=False):
    aria2c_enabled = self.connections > 0

    # create output path
    if not entry["name"]:
        entry["name"] = lib_etf.other.sane_name(entry["meta"]["title"])
    if not os.path.exists(entry["path"]):
        os.makedirs(entry["path"])
    output_path = os.path.join(entry["path"], entry["name"])
    self.log.info("Saving to:  " + output_path)

    # initialize other variables
    file_size = int(entry["meta"]["file_size"])
    hash = hashlib.md5()
    done = 0

    # check for an existing file
    skipped = 0
    headers = None
    if os.path.isfile(output_path) and not os.path.isfile(output_path + ".aria2"):
        skipped = os.path.getsize(output_path)
        if skipped == file_size:
            if existing_file_check_md5:
                self.log.info("File exists and has the same size as on the server. Doing an"
                              " additional MD5 hash check...")

                with open(output_path, "rb") as handle:
                    lib_etf.other.hash_beginning_of_file(handle, hash, chunk_size, file_size,
                                                         skipped, self.interactive)

                if hash.hexdigest() != entry["meta"]["md5_content"]:
                    raise ETFDownloadFatalError("MD5 does not match! (server: "
                                                + entry["meta"]["md5_content"] + ", client: " + hash.hexdigest())

                self.log.info("MD5 hash matches. Skipping this file...")
            else:
                self.log.info("File has been downloaded already, skipping... (It exists and"
                              " has the same size as on the server! To do an additional MD5 check here,"
                              " specify 'etf.py download -e' or 'existing_file_check_md5' in libetf.py)")
            return
        if skipped > file_size:
            raise ETFDownloadFatalError("File already exists and is bigger than the file on"
                                        " the server: " + output_path)
        if not auto_resume:
            raise ETFDownloadFatalError("File already exists and the auto_resume flag is not"
                                        " enabled.")
        self.log.info("Resuming at " + lib_etf.other.mib(skipped))

        if not aria2c_enabled:
            headers = {"Range": ("bytes=" + str(skipped) + "-")}

            # hash the beginning again
            with open(output_path, "rb") as handle:
                lib_etf.other.hash_beginning_of_file(handle, hash, chunk_size, file_size,
                                                     skipped, self.interactive)
            done = skipped

    if aria2c_enabled:
        self._download_aria2c(entry["id"], entry["meta"]["md5_content"], output_path)
    else:
        response = self.session.get(self.api_url + "download.php", stream=True,
                                    params={"etf_id": entry["id"]}, headers=headers, timeout=self.timeout, verify = False)
        if response.status_code != 200 and response.status_code != 206:
            raise IOError("(FROM SERVER) " + response.text)

        # download and hash the rest
        time_start = time.time()
        with open(output_path, "ab") as handle:
            for chunk in response.iter_content(chunk_size=chunk_size):
                done += len(chunk)
                handle.write(chunk)
                hash.update(chunk)
                if self.interactive:
                    lib_etf.progressbar.draw(skipped, file_size, done, time_start)

        if self.interactive:
            print()  # start a new line for log output

        if done != file_size:
            raise IOError("File size does not match, probably an aborted connection!")

        if hash.hexdigest() != entry["meta"]["md5_content"]:
            if entry["meta"]["md5_content"]:
                os.remove(output_path)
                raise IOError("MD5 does not match! (server: " + entry["meta"]["md5_content"]
                              + ", client: " + hash.hexdigest())
            else:
                self.log.info("NOTE: Server is still in the migrating phase, so the MD5 sum of"
                              " this file can not yet be verified. Clientside MD5: " + hash.hexdigest())

        else:
            self.log.info("MD5 verified, download successful!")


def download(self, etf_id: int, output_file=None, output_folder=None,
             chunk_size=1024 * 1024, allow_folder_download=True, create_subfolder=True,
             metadata=None, auto_resume=True, follow_associations=True, retry_attempts=10,
             retry_sleep=5, existing_file_check_md5=False):
    '''
        Download a file or a whole folder from the server and verify the `MD5` hash.
        Please note, that folder downloading does not work recursively, as this shouldn't
        be necessary.

        **output_file:** Clientside file name, default is the file name on the server.
            See also: [Download File Naming](#Download-Naming).

        **output_folder:** Clientside folder, default is the current folder.

        **chunk_size:** Size of what should be downloaded at once and put on the disk.
            Default is `1 MiB`. This option gets ignored, when the `connections` parameter
            of the `libetf` [constructor](#lib_etf.ETF.__init__) is `>0` (and therefore,
            `aria2` is used for downloading).

        **allow_folder_download:** When set to false, whole folders will never be
            downloaded. Instead, a `ETFDownloadFatalError` exception will be raised, in case
            the `etf_id` points to a folder.

        **create_subfolder:** When downloading a folder, and this flag is set to `true`,
            all downloaded files will be put in a new subfolder (that has the name
            associated with `etf_id`) inside `output_folder`.

        **metadata:** If you have downloaded the metadata already via `list()`, you can
            avoid an additional lookup by providing the data here.

        **auto_resume:** Automatically try to resume downloads, if the file exists and the
            file size is smaller on disk than on the server.

        **follow_associations:** If set to `True`, associations will be followed automatically.
            Associations to folders aren't being followed recursively (as with normal folders).
            More information about associations can be found in the [appendix](#Associations).

        **existing_file_check_md5:** When this flag is enabled and the `download`-method
            encounters an existing file with the same file size, it also verifies the MD5
            hash of the file.

        **retry_attempts:** Amount of automatic retries, when the connection breaks down.

        **retry_sleep:** Time to wait between retries, in seconds.

        **return value:** `True` on success, raises various exceptions on errors.
    '''

    retry_attempts = int(retry_attempts)
    retry_sleep = float(retry_sleep)
    queue = [{'id': etf_id, 'meta': metadata, 'name': output_file, 'path': output_folder}]
    done = 0

    for i in range(retry_attempts + 1):
        try:
            entry = None
            while len(queue):
                entry = queue.pop()
                self._download_entry_prepare(entry, queue, done)

                if entry["meta"]["entry_type"] == "FILE":
                    self._download_entry_file(entry, auto_resume, chunk_size,
                                              existing_file_check_md5)
                elif entry["meta"]["entry_type"] == "FOLDER":
                    self._download_entry_folder(entry, queue, done, allow_folder_download,
                                                create_subfolder)
                else:  # association
                    self._download_entry_association(entry, queue, follow_associations)
                done += 1

                self.log.info("")
        except ETFDownloadFatalError:
            raise
        except:
            self.log.debug(traceback.format_exc())
            self.log.error(str(sys.exc_info()[1]))
            if i == retry_attempts:
                self.log.critical("Download failed, no retries left!")
                raise
            self.log.error(str(retry_attempts - i - 1) + " retry attempts remaining.")
            self.log.error("Sleeping " + str(retry_sleep) + " seconds before retry...")
            time.sleep(retry_sleep)

            entry["meta"] = None
            queue.append(entry)

    return True
