#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import lib_etf.other
import os
import time


def remove(self, etf_id: int):
    '''
        **etf_id:** Entry, that should be deleted. You must have write access for that entry.
        Folders can only be deleted, if they do not contain any subfolders.

        This function returns a dictionary with the deleted elements or raises an `IOError`
            exception with an error message.
    '''

    ret = self.session.get(self.api_url + "remove.php", params={"etf_id": etf_id}, timeout=self.timeout)

    if ret.status_code != 200:
        raise LookupError("(FROM SERVER) " + ret.text)
    
    try:
        answer = ret.json()
    except:
        raise IOError("(FROM SERVER) " + ret.text)

    if answer["success"]:
        self.log.info("Deleted:")
        for el in answer["deleted_elements"]:
            type = el["entry_type"]
            title = el["title"]
            id = el["id"]
            self.log.info(type.ljust(11) + " " + str(id).rjust(10) + " " + title)
        return answer["deleted_elements"]
    else:
        raise IOError("(FROM SERVER) " + str(answer["reason"]))
