#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import json


def search(self, query, entry_type=None, ret_json=False):
    '''
        **query:** A search string for the fulltext search api call at ETF

        **entry_type:** the desired entry type, FILE, FOLDER or ASSOCIATION

        **ret_json:** Return the server's `JSON` output instead of a dictionary.

        **return value:** Server response `JSON` string or a dictionary.
    '''

    ret = self.session.post(self.api_url + "search.php",
                            data={"q": query, "t": entry_type}, timeout=self.timeout)

    if ret.status_code != 200:
        raise LookupError("(FROM SERVER) " + ret.text)

    if ret_json:
        return ret.text
    else:
        return ret.json()
