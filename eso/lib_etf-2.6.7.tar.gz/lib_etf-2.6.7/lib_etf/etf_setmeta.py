#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import json


def setmeta(self, etf_id: int, meta):
    '''
        **etf_id:** The folder id, where you want to change the metadata (user must have write
            access in there).

        **meta:** A dictionary with new metadata key-value pairs. Existing fields will not get
        deleted, if you do not specify them. Example: `{'description': "My new folder",
        'status': "Active", "eso_releases": ["first_release", "second_release"]}`

        [Here](#Metadata) is a list of all metadata fields, data types and their possible
        values. To build the dictionary from commandline parameters, have a look at
        [metadata_dict()](#lib_etf.metadata_dict).

        **return value:** `True` on success, otherwise an `IOError` with a message from the
            server gets raised.

        When the `etf_id` is invalid, a `LookupError` exception gets raised.
    '''

    ret = self.session.post(self.api_url + "setmeta.php",
                            data={"etf_id": etf_id, "meta": json.dumps(meta)}, timeout=self.timeout)
    
    if ret.status_code != 200:
        raise LookupError("(FROM SERVER) " + ret.text)

    try:
        answer = ret.json()
    except:
        raise IOError("(FROM SERVER) " + ret.text)

    if answer["success"]:
        self.log.info("Successfully changed metadata.")
        return True
    else:
        raise LookupError("(FROM SERVER) " + answer["reason"])
