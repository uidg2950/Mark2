#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import time
import sys


def clear():
    sys.stdout.write("\r")
    for i in range(0, 150):
        sys.stdout.write(" ")
    sys.stdout.write("\r")


def draw(size_skipped, size_total, size_done, time_start,
         char_done='=', char_skipped='*'):
    '''
        Displays a simple progress bar with the remaining time, for uploads and downloads.
    '''

    # avoid division by 0
    if size_total == 0:
        return

    if size_skipped > size_done:
        return draw(0, size_total, size_done, time_start, char_skipped)

    # do some calculations first
    elapsed = time.time() - time_start
    if elapsed == 0:
        elapsed = 0.00001  # Windows specific

    speed = (size_done - size_skipped) / elapsed / 1024
    percent = int(100 * size_done / size_total)
    str_percent = str(percent).rjust(3) + "%"
    str_remaining = "??:??"
    if speed > 0:
        remaining = (size_total - size_done) / speed / 1000
        str_remaining = str(int(remaining / 60)).zfill(2) + ":" + str(int(remaining % 60)).zfill(2)

    if speed < 1024:
        str_speed = str(int(speed)) + " KB/s"
    else:
        str_speed = str(int(speed / 1024)).rjust(4) + " MB/s"

    # progress bar
    skipped_len = int(50 * size_skipped / size_total)

    sys.stdout.write("\r")
    sys.stdout.write("[")
    for i in range(0, skipped_len):
        sys.stdout.write(char_skipped)
    for i in range(0, int(50 * size_done / size_total) - skipped_len):
        sys.stdout.write(char_done)
    sys.stdout.write(">")
    for i in range(int(percent / 2), 50): sys.stdout.write(" ")
    sys.stdout.write("]")

    # helpful information
    sys.stdout.write(" " + str_percent + "  " + str_remaining + " " + str_speed + "    ")
    sys.stdout.flush()
