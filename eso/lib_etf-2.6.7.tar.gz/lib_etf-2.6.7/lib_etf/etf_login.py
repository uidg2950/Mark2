#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import os
import getpass
from lib_etf.etf_encryption import encrypt_data

# Python3 compatibility. The 2to3 we're using doesn't cover this yet.
try:
    import configparser
except ImportError:
    import ConfigParser as configparser

class ETFAuthError(Exception):
    pass


def _login_load_credentials(self):
    self.config = configparser.ConfigParser()
    if type(self.credentials) is dict:
        self.log.debug("Got the credentials from a dictionary.")
        self.config.add_section("Credentials")
        self.config.set("Credentials", "Username", self.credentials["username"])
        self.config.set("Credentials", "Password", self.credentials["password"])
        return
    if os.getenv("ETF_USER"):
        self.log.debug("Got the credentials from the environment variables.")
        self.config.add_section("Credentials")
        self.config.set("Credentials", "Username", os.getenv("ETF_USER"))
        self.config.set("Credentials", "Password", os.getenv("ETF_PASS"))
        return

    # create the containing folders
    dir = os.path.dirname(self.credentials)
    if not os.path.exists(dir): os.makedirs(dir)

    if os.path.isfile(self.credentials):
        self.config.read(self.credentials)
    else:
        username = "CHANGEME"
        password = "CHANGEME"

        if self.interactive:
            self.log.info("Please type in the credentials for your API user.")
            self.log.info("They will be stored IN PLAINTEXT in " + self.credentials)
            self.log.info("NOTE: If you do not wish to store them on the disk, quit with")
            self.log.info("  CTRL+C and use the environment variables ETF_USER and ETF_PASS")
            self.log.info("  instead.")
            try:
                username = raw_input("Username: ")
            except:
                username = input("Username: ")  # python 3

            password = getpass.getpass("Password: ")

        handle = open(self.credentials, "w")
        self.config.add_section("Credentials")
        self.config.set("Credentials", "Username", username)
        self.config.set("Credentials", "Password", password)
        self.config.write(handle)
        handle.close()

        if not self.interactive:
            raise ETFAuthError("Please put your API user credentials in the"
                               " following file and try again (it has been created for you): "
                               + self.credentials)


def _login(self):
    '''
        Login and get the list of unfinished uploads. Raises an `ETFAuthError` exception on
        failure.
    '''

    passwd = encrypt_data(self, self.config.get("Credentials", "Password"))

    # Basic auth against f5
    response = self.session.post(
        self.api_url + "login.php",
        data={
            "user": self.config.get("Credentials", "Username"),
            "passwd": passwd,
            "encrypted": True,
        },
        auth=(
            self.config.get("Credentials", "Username"),
            passwd
        ),
        verify=False,
        timeout=self.timeout
    )

    if response.status_code != 200:
        raise ETFAuthError("(FROM F5 SERVER) " + response.text)

    ret = None
    try:
        ret = response.json()
    except ValueError:
        pass

    # workaround for additional login to ETF since f5 sends only
    if ret == None or ret["success"] == False:
        response = self.session.post(
            self.api_url + "login.php",
            data={
                "user": self.config.get("Credentials", "Username"),
                "passwd": passwd,
                "encrypted": True,
            },
            verify=False,
            timeout=self.timeout
        )

        try:
            ret = response.json()
        except ValueError:
            self.log.debug("Server: " + response.text)
            raise ETFAuthError("Connection to ETF server failed."
                               " (Are you running the latest API client?)")

    if ret["success"] == True:
        self.unfinished = ret["unfinished_uploads"]
        if ret["motd"]:
            self.log.info("Server: " + ret["motd"])
        return True
    elif ret["success"] == False and ret["reason"] == "Authentication failure!":
        self.log.critical("Login failed!")
        if os.getenv("ETF_USER"):
            raise ETFAuthError("Credentials from environment variables are wrong!"
                               " (Too many retries?)")
        if type(self.credentials) is dict:
            raise ETFAuthError("Credentials from dictionary are wrong! (Too many retries?)")
        os.remove(self.credentials)
        self._login_load_credentials()
        return False
    else:
        raise RuntimeError("(FROM SERVER) " + ret["reason"])
