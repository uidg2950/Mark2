#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2023 e.solutions GmbH
# This file is part of the ETF API Client (1402)
# Documentation: https://etf.esolutions.de/api
#
from __future__ import print_function, division, absolute_import
import requests
import getpass
import os
import sys
import time
import json
import inspect
import logging

# custom exceptions
from lib_etf.etf_login import ETFAuthError
from lib_etf.etf_download import ETFDownloadFatalError
from lib_etf.etf_download_aria2c import ETFParallelDownloadRequirementError
from lib_etf.etf_upload import ETFUploadFatalError

__version__ = "2.6.7"
__name__ = "lib_etf"


def credentials_file_default():
    '''
        Default path to the credentials file, depending on the operating system (POSIX or
        Windows). You can use this function to display the default path in your `--help`
        output for example.

        *If you do not want a credentials file, use the environment variables `ETF_USER`
        and `ETF_PASS` instead!*
    '''
    if os.name == "posix":
        return os.path.expanduser("~") + "/.config/etf/credentials"
    elif os.name == "nt":
        return os.environ['APPDATA'] + "\etf\credentials"
    return ".etf_credentials"


def metadata_dict(args, verbose):
    '''
        Parses metadata options from the commandline into a dictionary.

        **args:** A list of arguments, as returned by *argparse*. For example:

            [
                ["description=hello", "world"],
                ["status=pending"],
                ["eso_releases=first_release"],
                ["eso_releases=second_release"]
            ]

        **return value:** Dictionary, as expected by [setmeta()](#lib_etf.ETF.setmeta). The
            example from above would get transformed to:

            {
                "description": "hello world",
                "status": "pending",
                "eso_releases": ["first_release", "second_release"]
            }

    '''
    meta = dict()
    for arg in args:
        arg = " ".join(arg)
        split = arg.split('=', 1)
        if len(split) < 2:
            raise ValueError("Parsing metadata failed: argument '" + arg + "' doesn't have the"
                             + " key=value format!")

        # when the same key gets specified more than one, create a list (array)
        if split[0] in meta:
            if isinstance(meta[split[0]], list):
                meta[split[0]].append(split[1])
            else:
                meta[split[0]] = [meta[split[0]], split[1]]
        else:
            meta[split[0]] = split[1]

    logging.getLogger(__name__).debug("Parsed metadata: " + json.dumps(meta))

    return meta


def root_logger_setup(quiet=False, verbose=0):
    '''
        This function gets internally used to set up logging. If you do not want it to be used
        automatically, set `root_logger = False` in the	[constructor](#lib_etf.ETF.__init__).

        **quiet:** Only display critical `lib_etf` logs.

        **verbose:** Various degrees of verbosity, from `0` to `3`.
    '''
    if quiet and verbose:
        raise ValueError("Setting both the quiet and verbose flags makes no sense!")

    logger = logging.getLogger()

    # log format
    if verbose:
        if os.getenv("ETF_NO_TIMESTAMPS_IN_LOG"):
            logging.basicConfig(format="[%(levelname)8s %(module)-14s] %(message)s",
                                stream=sys.stdout)
        else:
            logging.basicConfig(format="[%(levelname)8s %(asctime)s %(module)-19s]"
                                       " %(message)s", datefmt='%H:%M:%S', stream=sys.stdout)
    else:
        logging.basicConfig(format='%(message)s', stream=sys.stdout)

    # default log levels
    logger.setLevel(logging.INFO)
    logging.getLogger("lib_etf.requests").setLevel(logging.WARNING)

    if quiet:
        logger.setLevel(logging.CRITICAL)
        logging.getLogger("lib_etf.requests").setLevel(logging.CRITICAL)

    if verbose:
        logger.setLevel(logging.DEBUG)
        if verbose > 1:  # -vv
            logging.getLogger("lib_etf.requests").setLevel(logging.INFO)
        if verbose > 2:  # -vvv
            logging.getLogger("lib_etf.requests").setLevel(logging.DEBUG)


class ETF(object):
    '''
        To use the API, import `lib_etf` and initialize a new ETF object. Look at the
        `__init__` method below for the constructor.
    '''

    # Naming convention:
    # Files with functions, that become methods of ETF have "etf_" as prefix.
    # All other files only contain helper functions.

    from lib_etf.etf_login import _login, _login_load_credentials
    from lib_etf.etf_mkassoc import mkassoc
    from lib_etf.etf_mkdir import mkdir
    from lib_etf.etf_remove import remove
    from lib_etf.etf_copy import copy
    from lib_etf.etf_setmeta import setmeta
    from lib_etf.etf_upload import (upload, upload_list_unfinished, _upload_chunk_url,
                                    _upload_get_resume_data, _upload_chunk, _upload_entry_file)
    from lib_etf.etf_download import (download, _download_entry_prepare,
                                      _download_entry_file, _download_entry_folder, _download_entry_association)
    from lib_etf.etf_download_aria2c import (_download_aria2c, _download_require_aria2c)
    from lib_etf.etf_search import search
    from lib_etf.etf_encryption import encrypt_data

    def __init__(self, script_company, script_name, script_version, interactive=False,
                 credentials=credentials_file_default(), quiet=False, verbose=0,
                 root_logger=True, beta_server=False, connections=0, timeout=None,
                 proxy_dict={}, alt_ssl=False):
        '''
            **script_company, script_name, script_version:** Unique identifier of your script,
                that makes debugging and support from the ETF developers easier.

            **interactive:** When set to `False`, the user will not see progress bars or be
                asked to type in the credentials. Instead a default file will be generated and
                a `ValueError`-exception gets raised. You can force the non-interactive mode
                by setting the environment variable `ETF_NON_INTERACTIVE`.

            **credentials:** If not specified, the default path gets determined by
                `credentials_file_default()`. In case it does not exist yet, the file gets
                created (this also includes parent folders, that do not exist yet).
                It is also possible to pass a dictionary:
                `{"username" : "CHANGEME", "password" : "CHANGEME"}`

            *If you don't want to store the credentials in a file, you may also
                put the credentials in the environment variables `ETF_USER` and `ETF_PASS`.*

            **verbose:** (requires `root_logger=True`)**:** Set this to a number from `1` to
                `3` to print out URLs and other debug information. Higher numbers mean more
                messages.

            **quiet:** (requires `root_logger=True`)**:** Some information, for example the
                downloaded file names, gets printed out by default (even without `verbose`).
                When `quiet` is set, there's no output written to the terminal at all except
                for critical errors.

            **root_logger:** Set this to `False` to use your own root logger. This is for more
                advanced Python users, that wish `lib_etf` to behave more like normal Python
                libraries. By default, the [`root_logger_setup`](#lib_etf.root_logger_setup)
                method will get called and set up a logger based on the `verbose` and `quiet`
                flags (see above).

            **beta_server:** Set this to `True` to use the ETF beta server
                (`etf-beta.esolutions.de`). Remember, that your API account needs to have the
                `ETF_Beta` right (request it, like all other rights, as described in the
                [API User Account](#Account) appendix).

            **connections:** Set this to `>0` to enable multiple parallel
                download connections. Only do this, if you do not have fast downloads already!
                This is only supported on GNU/Linux and requires the commandline program
                [`aria2`](https://aria2.github.io/) to be installed (use your distributions
                package manager).

            **timeout:** Connections timeout for the requests package. By default, requests do not time out.
                You can specify a single value for timeout or separate values for connect and read timeout as a tuple.
                Detailed explanation how the timeout works is available at the [`requests documentation`](https://2.python-requests.org/en/master/user/advanced/#id16).

            **proxy_dict:** (https://requests.readthedocs.io/en/latest/user/advanced/#proxies)

            **alt_ssl:** file path to a alternative ssl certificate, that should be used instead
                of the provided one

            This constructor raises a `lib_etf.ETFAuthError` exception on failed login and a
            `lib_etf.ETFParallelDownloadRequirementError` exception in case parallel downloads
            were requested, but are not support on the user's system.
        '''

        if root_logger:
            root_logger_setup(quiet, verbose)

        if logging.getLogger("lib_etf").getEffectiveLevel() > logging.INFO:
            interactive = False

        self.log = logging.getLogger(__name__)
        self.log.addHandler(logging.NullHandler())
        self.credentials = credentials
        self.interactive = False if os.getenv("ETF_NON_INTERACTIVE") else interactive
        self._login_load_credentials()
        self.api_url = "https://etf.esolutions.de/common/api/"
        self.session = requests.Session()
        self.session.verify = False
        self.session.hooks = {"response": self._response_hook}
        self.session.headers["user-agent"] += \
            " lib_etf.py/" + __version__ + " " + script_name + "/" + script_version + \
            " (" + script_company + ")"
        self.session.proxies = proxy_dict
        if os.getenv("ETF_USER_AGENT_SUFFIX"):
            self.session.headers["user-agent"] += " " + os.getenv("ETF_USER_AGENT_SUFFIX")
        if os.getenv("ETF_API_URL"):
            self.api_url = os.getenv("ETF_API_URL")
        if beta_server:
            self.api_url = "https://etf-beta.esolutions.de/common/api/"
        if os.getenv("ETF_API_HTTP_AUTH_USER"):
            self.session.auth = requests.auth.HTTPDigestAuth(
                os.getenv("ETF_API_HTTP_AUTH_USER"), os.getenv("ETF_API_HTTP_AUTH_PASS"))

        # Set the server's TLS certificate ( http://stackoverflow.com/a/50905 )
        script_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        self.session.verify = script_path + "/server.pem"
        
        # connection timeout or connection and response timeout as tuple
        self.timeout = timeout

        # Fixes for Ubuntu 12.04:
        # https://github.com/kennethreitz/requests/issues/557#issuecomment-6420819
        os.environ['REQUESTS_CA_BUNDLE'] = self.session.verify

        # Disable urllib3 Warnings, because:
        # - We only connect to the ETF server
        # - We only allow the ETF server certificate bundle anyway (it's in server.pem)
        try:
            requests.packages.urllib3.disable_warnings()
        except:
            # This doesn't work on Python 3. But in Python 3, urllib3 doesn't print warnings
            # anyway, so it's fine.
            pass

        while True:
            if self._login(): break

        self.log.debug("Logged in as " + self.config.get("Credentials", "Username") + ".")

        # ETF-379: support parallel downloads
        self.connections = connections
        if connections > 0:
            self._download_require_aria2c()



    def _response_hook(self, request, *args, **kwargs):
        self.log.debug(" > " + request.url)

    # in ETF-testsuite
    def list(self, etf_id: int = 1, ret_json=False):
        '''
            List file metadata. If the given `etf_id` is a folder, it also lists all files
            inside that folder. The listing is not recursive.

            **etf_id:** Default is `1`, the root folder.

            **ret_json:** Return the server's `JSON` output instead of a dictionary.

            When the `etf_id` is invalid, a `LookupError` exception gets raised.
        '''
        ret = self.session.get(self.api_url + "list.php?etf_id=" + str(etf_id), timeout=self.timeout, verify = False)
        if ret.status_code != 200:
            raise LookupError("(FROM SERVER) " + ret.text)

        if ret_json:
            return ret.text
        else:
            return ret.json()
