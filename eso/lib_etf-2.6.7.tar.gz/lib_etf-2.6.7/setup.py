#!/usr/bin/env python
# -*- coding: utf-8 -*-
from setuptools import setup, find_packages
from lib_etf import __version__, __name__

package_dir = {'': 'lib_etf'}
setup(
    name=__name__,
    version=__version__,
    long_description=open('./README.txt').read(),
    keywords=['ETF', 'lib_etf', 'e.solutions GmbH', 'ESO team files'],
    url='https://etf.esolutions.de',
    author='e.solutions GmbH',
    author_email='etf-support@esolutions.de',
    project_urls={
        'Documentation': 'https://etf.esolutions.de/api/'
    },
    packages=find_packages(),
    install_requires=[
        'requests',
        'cryptography'
    ],
    include_package_data=True,
    zip_safe=False,
    use_2to3=False,
	python_requires='>=3.6'
)
