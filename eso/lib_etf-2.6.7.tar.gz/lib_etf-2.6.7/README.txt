============================
e.solutions Team Files (ETF)
============================

positional arguments:
=====================
  etf_id                ETF-ID of a file, folder or association

optional arguments:
===================
  -h, --help            show this help message and exit
  -V, --version         show program's version number and exit
  --beta                use etf-beta.esolutions.de instead of
                        etf.esolutions.de
  -c CREDENTIALS_FILE   location of credentials file (will be created if it
                        doesn't exist), default:
                        \Users\*\AppData\Roaming\etf\credentials
                        Instead of a credentials file, you may also use these
                        environment variables: ETF_USER, ETF_PASS
  -q, -s                quiet (silent) output, except for the results of list,
                        upload, mkdir, mkassoc
  -v                    verbose output for debugging
  -n                    non-interactive mode
  -p                    run profiler to find CPU bottlenecks

actions:
========
  Action that will be performed on the ETF-ID. To get a list of action
  arguments, run `etf.py list -h` (replace "list" with the action that you
  want to look up). (rw) means: read-write access rights required.

  {list,download,upload,mkassoc,mkdir,rm,setmeta,copy}
    list                list all metadata from files and folders
    download            download a single file or a whole folder (not
                        recursive!)
    upload              upload one or more files to the folder with ETF-ID
                        (rw)
    mkassoc             create a link inside the folder with ETF-ID (rw)
    mkdir               create a new subfolder inside the folder with ETF-ID
                        (rw)
    rm                  Delete one file, folder or association. Folders can
                        only be deleted, if they do not contain subfolders.
                        (rw)
    setmeta             change metadata (eg. to rename an element or set the
                        status) (rw)
    copy                Copy files, folders or associations. Folders can only
                        be copied, if they do not contain subfolders. (rw)

For more infos please visit https://etf.esolutions.de/api/
You'll be able to view the API documentation page after a successfully sign-in into the ETF.